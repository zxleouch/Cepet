# punten-g0pud
Gunakan dengan bijak!

how?
$git clone https://github.com/k4xc0d3-12/punten-g0pud
$cd punten-g0pud
$php dorrr.php


